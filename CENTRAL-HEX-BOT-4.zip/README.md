# 💎 CENTRAL-HEX WhatsApp Bot

**Le bot officiel de la communauté CENTRAL-HEX**

## 👤 Propriétaire
- **Nom** : Ibrahima Sory Sacko
- **Contact** : +224666952949
- **Communauté** : CENTRAL-HEX

## 🚀 Installation

```bash
npm install
node index.js
```

## 📋 Commandes
Plus de 90 commandes disponibles !

## 💎 Rejoindre CENTRAL-HEX
https://whatsapp.com/channel/0029VbC8YkY7oQhiOiiSpy1z
