const settings = {
  packname: '💎 CENTRAL-HEX',
  author: 'Ibrahima Sory Sacko',
  botName: "CENTRAL-HEX",
  botOwner: 'Ibrahima Sory Sacko',
  ownerNumber: '224666952949',
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20,
  storeWriteInterval: 10000,
  description: "CENTRAL-HEX — Le bot de la famille HEX 💎",
  version: "1.0.0",
  updateZipUrl: "https://github.com/CENTRAL-HEX",
};

module.exports = settings;
