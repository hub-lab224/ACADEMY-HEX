const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');
const settings = require('../settings');

async function helpCommand(sock, chatId, message, channelLink) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    const uptimeString = `${hours}h ${minutes}m ${seconds}s`;

    const date = moment().tz('Africa/Conakry').format('DD/MM/YYYY');
    const time = moment().tz('Africa/Conakry').format('HH:mm:ss');

    const helpMessage =
`╭⊰🥷⊱═══════════⊰🥷⊱
║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`
╰⊰🥷⊱═══════════⊰🥷⊱
╭═══════════════⊰۞⊱
╠╌ 👤 𝙾𝚆𝙽𝙴𝚁 : ${settings.botOwner}
╠╌ ⏰ 𝙷𝙴𝚄𝚁𝙴 : ${time}
╠╌ 📅 𝙳𝙰𝚃𝙴 : ${date}
╠╌ 📦 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : v${settings.version}
╠╌ 📋 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝙴𝚂 : 133
╠╌ ⚡ 𝚃𝚈𝙿𝙴 : case
╠╌ 🔑 𝙿𝚁𝙴𝙵𝙸𝚇 : [ . ]
╠╌ 🕐 𝚄𝙿𝚃𝙸𝙼𝙴 : ${uptimeString}
╰⊰۞⊱════════════⊰۞⊱

⊰★⊱❐ ⌜𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒⌟ ❐ ⊰★⊱

╭⊰ \`𝐆𝐄𝐍𝐄𝐑𝐀𝐋\` ⊱ 📃
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ menu
╠🥷 ❐ ping
╠🥷 ❐ uptime
╠🥷 ❐ alive
╠🥷 ❐ owner
╠🥷 ❐ speed
╠🥷 ❐ script
╠🥷 ❐ repo
╠🥷 ❐ support
╠🥷 ❐ developer
╠🥷 ❐ updates
╠🥷 ❐ credits
╠🥷 ❐ tennor
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐏𝐑𝐎𝐏𝐑𝐈𝐄𝐓𝐀𝐈𝐑𝐄\` ⊱ 👑
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ setprefix
╠🥷 ❐ setowner
╠🥷 ❐ setbotname
╠🥷 ❐ setmenuimg
╠🥷 ❐ setbotimg
╠🥷 ❐ public
╠🥷 ❐ self
╠🥷 ❐ addprem
╠🥷 ❐ delprem
╠🥷 ❐ antidelete
╠🥷 ❐ anticall
╠🥷 ❐ autoviewstatus
╠🥷 ❐ autolikestatus
╠🥷 ❐ block
╠🥷 ❐ unblock
╠🥷 ❐ broadcast
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐆𝐑𝐎𝐔𝐏𝐄\` ⊱ 👥
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ promote
╠🥷 ❐ demote
╠🥷 ❐ kick
╠🥷 ❐ mute
╠🥷 ❐ unmute
╠🥷 ❐ tagall
╠🥷 ❐ tagadmins
╠🥷 ❐ grouplink
╠🥷 ❐ revoke
╠🥷 ❐ groupinfo
╠🥷 ❐ setgname
╠🥷 ❐ setgdesc
╠🥷 ❐ hidetag
╠🥷 ❐ warn
╠🥷 ❐ resetwarn
╠🥷 ❐ warnings
╠🥷 ❐ antilink
╠🥷 ❐ antispam
╠🥷 ❐ antibadword
╠🥷 ❐ antimarabout
╠🥷 ❐ welcome
╠🥷 ❐ goodbye
╠🥷 ❐ lock
╠🥷 ❐ unlock
╠🥷 ❐ everyone
╠🥷 ❐ admins
╠🥷 ❐ members
╠🥷 ❐ listgroups
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐔𝐓𝐈𝐋𝐈𝐓𝐀𝐈𝐑𝐄\` ⊱ 🛠️
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ sticker
╠🥷 ❐ toimg
╠🥷 ❐ vv
╠🥷 ❐ qr
╠🥷 ❐ weather
╠🥷 ❐ tr
╠🥷 ❐ tts
╠🥷 ❐ tourl
╠🥷 ❐ ocr
╠🥷 ❐ shorten
╠🥷 ❐ play
╠🥷 ❐ playdoc
╠🥷 ❐ getpp
╠🥷 ❐ setmypp
╠🥷 ❐ uploadstatus
╠🥷 ❐ idch
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐅𝐔𝐍\` ⊱ 🎮
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ joke
╠🥷 ❐ fact
╠🥷 ❐ quote
╠🥷 ❐ dare
╠🥷 ❐ truth
╠🥷 ❐ riddle
╠🥷 ❐ roast
╠🥷 ❐ ship
╠🥷 ❐ coinflip
╠🥷 ❐ dice
╠🥷 ❐ magic8
╠🥷 ❐ horoscope
╠🥷 ❐ meme
╠🥷 ❐ cat
╠🥷 ❐ dog
╠🥷 ❐ waifu
╠🥷 ❐ anime
╠🥷 ❐ trivia
╠🥷 ❐ compliment
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐏𝐄𝐔𝐑\` ⊱ 💻
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ eval
╠🥷 ❐ github
╠🥷 ❐ uuid
╠🥷 ❐ password
╠🥷 ❐ b64enc
╠🥷 ❐ b64dec
╠🥷 ❐ hexenc
╠🥷 ❐ hexdec
╠🥷 ❐ md5
╠🥷 ❐ sha256
╠🥷 ❐ sha512
╠🥷 ❐ ipinfo
╠🥷 ❐ whois
╠🥷 ❐ dns
╠🥷 ❐ checkurl
╠🥷 ❐ lorem
╠🥷 ❐ timestamp
╠🥷 ❐ minify
╠🥷 ❐ beautify
╠🥷 ❐ regex
╰⊰۞⊱═════════════⊰۞⊱

╭⊰🥷⊱═══════════⊰🥷⊱
║  💎 *CENTRAL-HEX*
║  by *Ibrahima Sory Sacko*
╰⊰🥷⊱═══════════⊰🥷⊱`;

    const channelInfo = {
        contextInfo: {
            forwardingScore: 1,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '120363161513685998@newsletter',
                newsletterName: 'CENTRAL-HEX',
                serverMessageId: -1
            }
        }
    };

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        if (fs.existsSync(imagePath)) {
            await sock.sendMessage(chatId, {
                image: { url: imagePath },
                caption: helpMessage,
                ...channelInfo
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, {
                text: helpMessage,
                ...channelInfo
            }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage }, { quoted: message });
    }
}

module.exports = helpCommand;
