// codeai.js — CENTRAL-HEX
const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

async function callAI(prompt) {
    const enc = encodeURIComponent(prompt);
    const apis = [
        { url: `https://text.pollinations.ai/${enc}`, type: 'text' },
        { url: `https://api.giftedtech.my.id/api/ai/gpt4?apikey=gifted&query=${enc}`, keys: ['result','response'] },
        { url: `https://api.siputzx.my.id/api/ai/meta-llama?content=${enc}`, keys: ['data','result'] },
    ];
    for (const api of apis) {
        try {
            const r = await axios.get(api.url, { timeout: 20000, responseType: api.type === 'text' ? 'text' : 'json' });
            if (api.type === 'text') { if (r.data && r.data.length > 5) return r.data; }
            else { for (const k of api.keys) { const v = r.data?.[k]; if (v && v.length > 5) return v; } }
        } catch {}
    }
    throw new Error('IA indisponible. Réessaie.');
}

async function codeaiCommand(sock, chatId, message, query) {
    if (!query) return sock.sendMessage(chatId, {
        text: '❌ Usage: *.codeai <demande>*\nEx: .codeai crée une fonction Python',
        ...channelInfo
    }, { quoted: message });
    try {
        await sock.sendMessage(chatId, { text: '💻 *Génération du code...*', ...channelInfo }, { quoted: message });
        const answer = await callAI(`Expert développeur. Code propre + commenté pour: ${query}`);
        await sock.sendMessage(chatId, {
            text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n💻 *CODE AI*\n╭═══════════════⊰۞⊱\n📋 *Demande :* ${query}\n╰⊰۞⊱════════════⊰۞⊱\n\n📝 *Code :*\n${answer.slice(0, 3500)}\n\n> 💎 *CENTRAL-HEX*`,
            ...channelInfo
        }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ ${e.message}`, ...channelInfo }, { quoted: message });
    }
}
module.exports = codeaiCommand;
