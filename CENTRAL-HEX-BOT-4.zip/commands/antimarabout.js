const { setAntimarabout } = require('../lib/index');

async function antimaraboutCommand(sock, chatId, message, senderId, isSenderAdmin) {
    if (!isSenderAdmin) {
        return sock.sendMessage(chatId, { text: '*Désolé, seuls les administrateurs peuvent utiliser cette commande.*' }, { quoted: message });
    }

    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = text.split(' ');
    const match = args[1];

    if (!match) {
        return sock.sendMessage(chatId, {
            text: `*CONFIGURATION ANTIMARABOUT*\n\n*.antimarabout on*\nActiver l'antimarabout\n\n*.antimarabout set <action>*\nDéfinir l'action: delete/kick\n\n*.antimarabout off*\nDésactiver l'antimarabout`
        }, { quoted: message });
    }

    if (match === 'on') {
        await setAntimarabout(chatId, 'on', 'delete');
        return sock.sendMessage(chatId, { text: '*L\'Antimarabout a été activé (Action par défaut: delete).*' }, { quoted: message });
    }

    if (match === 'off') {
        await setAntimarabout(chatId, 'off');
        return sock.sendMessage(chatId, { text: '*L\'Antimarabout a été désactivé.*' }, { quoted: message });
    }

    if (match === 'set') {
        const action = args[2];
        if (!action || !['delete', 'kick'].includes(action)) {
            return sock.sendMessage(chatId, { text: '*Action invalide. Choisissez: delete ou kick.*' }, { quoted: message });
        }
        await setAntimarabout(chatId, 'on', action);
        return sock.sendMessage(chatId, { text: `*L'action Antimarabout a été définie sur: ${action}*` }, { quoted: message });
    }

    return sock.sendMessage(chatId, { text: '*Commande invalide. Utilisez .antimarabout pour voir l\'aide.*' }, { quoted: message });
}

module.exports = antimaraboutCommand;
