const { channelInfo } = require('../lib/messageConfig');
const dares = ["Envoie un message à la dernière personne de ta liste de contacts.","Chante une chanson et envoie le vocal ici.","Envoie le dernier mème que tu as sauvegardé.","Dis quelque chose en anglais/arabe/espagnol.","Écris 'Je suis le/la meilleur(e)' 10 fois.","Raconte ta pire blague ici.","Fais 10 pompes et envoie une vidéo en preuve.","Appelle un ami et dis-lui que tu as un secret important."];
async function dareCommand(sock, chatId, message) {
    const dare = dares[Math.floor(Math.random() * dares.length)];
    await sock.sendMessage(chatId, { text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n🎯 *ACTION (DARE)*\n━━━━━━━━━━━━━━━━━━\n${dare}\n\n> 💎 *CENTRAL-HEX*`, ...channelInfo }, { quoted: message });
}
module.exports = dareCommand;
