const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');
const jokes = ["Pourquoi les devs préfèrent le dark mode ? La lumière attire les bugs ! 🐛","Un dev entre dans un bar. 1 bière. 0 bières. 999 bières.","Comment appelle-t-on un dev qui fait du sport ? Un runner JavaScript !","Mon code ne marche pas. Je ne sais pas pourquoi. Mon code marche. Je ne sais pas pourquoi.","Il y a 10 types de personnes : ceux qui comprennent le binaire et les autres.","Comment appelle-t-on un bug qu'on ne peut pas reproduire ? Une fonctionnalité.","La vie est courte, utilisez Python... ou un bot WhatsApp !","Pourquoi le bot est-il toujours fatigué ? Il travaille sans relâche ! 😅"];
async function jokeCommand(sock, chatId, message) {
    let joke = jokes[Math.floor(Math.random() * jokes.length)];
    try { const r = await axios.get('https://icanhazdadjoke.com/', { headers: { Accept: 'application/json' }, timeout: 8000 }); if (r.data?.joke) joke = r.data.joke; } catch {}
    await sock.sendMessage(chatId, { text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n😂 *BLAGUE DU JOUR*\n━━━━━━━━━━━━━━━━━━\n${joke}\n\n> 💎 *CENTRAL-HEX*`, ...channelInfo }, { quoted: message });
}
module.exports = jokeCommand;
