const { v4: uuidv4 } = require('uuid');
const crypto = require('crypto');
const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

function box(title, content) {
    return `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n${title}\n━━━━━━━━━━━━━━━━━━\n${content}\n\n> 💎 *CENTRAL-HEX*`;
}

async function uuidCommand(sock, chatId, message) {
    const id = uuidv4();
    await sock.sendMessage(chatId, { text: box('🔑 *UUID GÉNÉRÉ*', `\`${id}\``), ...channelInfo }, { quoted: message });
}

async function passwordCommand(sock, chatId, message, args) {
    const length = Math.min(parseInt(args[0]) || 16, 64);
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=';
    let pwd = '';
    for (let i = 0; i < length; i++) pwd += chars[Math.floor(Math.random() * chars.length)];
    await sock.sendMessage(chatId, { text: box('🔒 *MOT DE PASSE GÉNÉRÉ*', `\`${pwd}\`\n📏 Longueur : ${length}`), ...channelInfo }, { quoted: message });
}

async function b64encCommand(sock, chatId, message, text) {
    if (!text) return sock.sendMessage(chatId, { text: '❌ Usage : *.b64enc <texte>*', ...channelInfo }, { quoted: message });
    const encoded = Buffer.from(text).toString('base64');
    await sock.sendMessage(chatId, { text: box('📦 *BASE64 ENCODÉ*', `Original : ${text}\nEncodé : \`${encoded}\``), ...channelInfo }, { quoted: message });
}

async function b64decCommand(sock, chatId, message, text) {
    if (!text) return sock.sendMessage(chatId, { text: '❌ Usage : *.b64dec <texte>*', ...channelInfo }, { quoted: message });
    try {
        const decoded = Buffer.from(text, 'base64').toString('utf-8');
        await sock.sendMessage(chatId, { text: box('📦 *BASE64 DÉCODÉ*', `Encodé : ${text}\nDécodé : \`${decoded}\``), ...channelInfo }, { quoted: message });
    } catch { await sock.sendMessage(chatId, { text: '❌ Texte base64 invalide.', ...channelInfo }, { quoted: message }); }
}

async function md5Command(sock, chatId, message, text) {
    if (!text) return sock.sendMessage(chatId, { text: '❌ Usage : *.md5 <texte>*', ...channelInfo }, { quoted: message });
    const hash = crypto.createHash('md5').update(text).digest('hex');
    await sock.sendMessage(chatId, { text: box('🔐 *HASH MD5*', `Texte : ${text}\nMD5 : \`${hash}\``), ...channelInfo }, { quoted: message });
}

async function sha256Command(sock, chatId, message, text) {
    if (!text) return sock.sendMessage(chatId, { text: '❌ Usage : *.sha256 <texte>*', ...channelInfo }, { quoted: message });
    const hash = crypto.createHash('sha256').update(text).digest('hex');
    await sock.sendMessage(chatId, { text: box('🔐 *HASH SHA256*', `Texte : ${text}\nSHA256 : \`${hash}\``), ...channelInfo }, { quoted: message });
}

async function ipinfoCommand(sock, chatId, message, ip) {
    try {
        const r = await axios.get(`https://ipapi.co/${ip || 'json'}/json/`, { timeout: 10000 });
        const d = r.data;
        await sock.sendMessage(chatId, { text: box('🌐 *INFOS IP*', `📍 IP : ${d.ip}\n🌍 Pays : ${d.country_name}\n🏙️ Ville : ${d.city}\n🏢 FAI : ${d.org}\n🕐 Fuseau : ${d.timezone}`), ...channelInfo }, { quoted: message });
    } catch { await sock.sendMessage(chatId, { text: '❌ Impossible de trouver les infos IP.', ...channelInfo }, { quoted: message }); }
}

async function whoisCommand(sock, chatId, message, domain) {
    if (!domain) return sock.sendMessage(chatId, { text: '❌ Usage : *.whois <domaine>*', ...channelInfo }, { quoted: message });
    try {
        const r = await axios.get(`https://api.domainsdb.info/v1/domains/search?domain=${domain}&limit=1`, { timeout: 10000 });
        const d = r.data?.domains?.[0];
        await sock.sendMessage(chatId, { text: box(`🌐 *WHOIS : ${domain}*`, `Enregistré : ${d ? '✅ Oui' : '❌ Non'}\nCréation : ${d?.create_date || 'Inconnu'}\nPays : ${d?.country || 'Inconnu'}`), ...channelInfo }, { quoted: message });
    } catch { await sock.sendMessage(chatId, { text: '❌ Erreur WHOIS.', ...channelInfo }, { quoted: message }); }
}

async function timestampCommand(sock, chatId, message) {
    const now = new Date();
    await sock.sendMessage(chatId, { text: box('⏰ *HORODATAGE*', `Unix : \`${Math.floor(now.getTime()/1000)}\`\nMs : \`${now.getTime()}\`\nISO : \`${now.toISOString()}\`\nFR : ${now.toLocaleString('fr-FR')}`), ...channelInfo }, { quoted: message });
}

async function loremCommand(sock, chatId, message, args) {
    const count = Math.min(parseInt(args[0]) || 1, 5);
    const lorem = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.";
    const text = Array(count).fill(lorem).join('\n\n');
    await sock.sendMessage(chatId, { text: box('📝 *LOREM IPSUM*', text), ...channelInfo }, { quoted: message });
}

async function shortenCommand(sock, chatId, message, url) {
    if (!url) return sock.sendMessage(chatId, { text: '❌ Usage : *.shorten <URL>*', ...channelInfo }, { quoted: message });
    try {
        const r = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`, { timeout: 10000 });
        await sock.sendMessage(chatId, { text: box('🔗 *LIEN RACCOURCI*', `Original : ${url.slice(0,50)}...\nCourt : ${r.data}`), ...channelInfo }, { quoted: message });
    } catch { await sock.sendMessage(chatId, { text: '❌ Erreur raccourcissement.', ...channelInfo }, { quoted: message }); }
}

module.exports = { uuidCommand, passwordCommand, b64encCommand, b64decCommand, md5Command, sha256Command, ipinfoCommand, whoisCommand, timestampCommand, loremCommand, shortenCommand };
