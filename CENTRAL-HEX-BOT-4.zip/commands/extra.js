const axios = require('axios');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const QRCode = require('qrcode');
const { channelInfo } = require('../lib/messageConfig');
const settings = require('../settings');

function box(title, content) {
    return `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n${title}\n━━━━━━━━━━━━━━━━━━\n${content}\n\n> 💎 *CENTRAL-HEX*`;
}

// UPTIME
async function uptimeCommand(sock, chatId, message) {
    const s = Math.floor(process.uptime());
    const h = Math.floor(s/3600), m = Math.floor((s%3600)/60), sec = Math.floor(s%60);
    await sock.sendMessage(chatId, {
        text: box('⏱️ *TEMPS EN LIGNE*', `🕐 ${h}h ${m}m ${sec}s\n📦 Version : v${settings.version}`),
        ...channelInfo
    }, { quoted: message });
}

// SPEED
async function speedCommand(sock, chatId, message) {
    const start = Date.now();
    await sock.sendMessage(chatId, { text: '⏳ Test en cours...', ...channelInfo }, { quoted: message });
    const ping = Date.now() - start;
    const icon = ping < 100 ? '🟢' : ping < 300 ? '🟡' : '🔴';
    await sock.sendMessage(chatId, {
        text: box('⚡ *VITESSE*', `${icon} Ping : *${ping}ms*\n💾 RAM : ${(process.memoryUsage().rss/1024/1024).toFixed(1)} MB`),
        ...channelInfo
    }, { quoted: message });
}

// TOIMG (sticker → image)
async function toimgCommand(sock, chatId, message) {
    try {
        const ctx = message.message?.extendedTextMessage?.contextInfo;
        const quoted = ctx?.quotedMessage;
        if (!quoted?.stickerMessage) {
            return sock.sendMessage(chatId, {
                text: '❌ Réponds à un *sticker* avec *.toimg* pour le convertir en image.',
                ...channelInfo
            }, { quoted: message });
        }
        const targetMsg = {
            key: { remoteJid: chatId, id: ctx.stanzaId, participant: ctx.participant, fromMe: false },
            message: quoted
        };
        const buffer = await downloadMediaMessage(targetMsg, 'buffer', {});
        if (!buffer) throw new Error('Téléchargement échoué');
        await sock.sendMessage(chatId, {
            image: buffer,
            caption: '✅ Sticker converti en image !\n\n> 💎 *CENTRAL-HEX*',
            ...channelInfo
        }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ Erreur: ${e.message}`, ...channelInfo }, { quoted: message });
    }
}

// QR CODE
async function qrCommand(sock, chatId, message, text) {
    if (!text) return sock.sendMessage(chatId, {
        text: '❌ Usage : *.qr <texte ou lien>*\nEx : .qr https://google.com',
        ...channelInfo
    }, { quoted: message });
    try {
        const qrBuffer = await QRCode.toBuffer(text, { width: 400 });
        await sock.sendMessage(chatId, {
            image: qrBuffer,
            caption: `✅ QR Code généré pour :\n${text}\n\n> 💎 *CENTRAL-HEX*`,
            ...channelInfo
        }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ Erreur QR: ${e.message}`, ...channelInfo }, { quoted: message });
    }
}

// GETPP (photo de profil)
async function getppCommand(sock, chatId, message, mentionedJids) {
    try {
        const target = mentionedJids?.[0] || (chatId.endsWith('@g.us') ? null : chatId);
        if (!target) return sock.sendMessage(chatId, {
            text: '❌ Mentionne une personne : *.getpp @user*',
            ...channelInfo
        }, { quoted: message });
        const ppUrl = await sock.profilePictureUrl(target, 'image');
        await sock.sendMessage(chatId, {
            image: { url: ppUrl },
            caption: `📸 Photo de profil de @${target.split('@')[0]}\n\n> 💎 *CENTRAL-HEX*`,
            mentions: [target],
            ...channelInfo
        }, { quoted: message });
    } catch {
        await sock.sendMessage(chatId, { text: '❌ Pas de photo de profil disponible.', ...channelInfo }, { quoted: message });
    }
}

// SETPREFIX
async function setprefixCommand(sock, chatId, message, newPrefix) {
    if (!newPrefix) return sock.sendMessage(chatId, {
        text: '❌ Usage : *.setprefix <symbole>*\nEx : .setprefix !',
        ...channelInfo
    }, { quoted: message });
    settings.prefix = newPrefix;
    await sock.sendMessage(chatId, {
        text: box('⚙️ *PRÉFIXE CHANGÉ*', `Nouveau préfixe : *${newPrefix}*\n\n💡 Ex: ${newPrefix}menu, ${newPrefix}ping`),
        ...channelInfo
    }, { quoted: message });
}

// SELF mode
async function selfCommand(sock, chatId, message) {
    settings.commandMode = 'self';
    await sock.sendMessage(chatId, {
        text: box('⚙️ *MODE SELF*', '🔒 Le bot répond uniquement à l\'owner.'),
        ...channelInfo
    }, { quoted: message });
}

// BROADCAST
async function broadcastCommand(sock, chatId, message, text) {
    if (!text) return sock.sendMessage(chatId, {
        text: '❌ Usage : *.broadcast <message>*',
        ...channelInfo
    }, { quoted: message });
    try {
        const groups = await sock.groupFetchAllParticipating();
        let sent = 0;
        for (const [id] of Object.entries(groups)) {
            try {
                await sock.sendMessage(id, { text: `📢 *Diffusion CENTRAL-HEX*\n\n${text}\n\n> 💎 *CENTRAL-HEX*`, ...channelInfo });
                sent++;
                await new Promise(r => setTimeout(r, 1000));
            } catch {}
        }
        await sock.sendMessage(chatId, { text: `✅ Message envoyé dans *${sent}* groupes !`, ...channelInfo }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ Erreur: ${e.message}`, ...channelInfo }, { quoted: message });
    }
}

// GROUPLINK
async function grouplinkCommand(sock, chatId, message) {
    if (!chatId.endsWith('@g.us')) return sock.sendMessage(chatId, { text: '❌ Groupe uniquement.', ...channelInfo }, { quoted: message });
    try {
        const code = await sock.groupInviteCode(chatId);
        await sock.sendMessage(chatId, {
            text: box('🔗 *LIEN DU GROUPE*', `https://chat.whatsapp.com/${code}`),
            ...channelInfo
        }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ Erreur: ${e.message}`, ...channelInfo }, { quoted: message });
    }
}

// UNLOCK
async function unlockCommand(sock, chatId, message) {
    if (!chatId.endsWith('@g.us')) return sock.sendMessage(chatId, { text: '❌ Groupe uniquement.', ...channelInfo }, { quoted: message });
    try {
        await sock.groupSettingUpdate(chatId, 'not_announcement');
        await sock.sendMessage(chatId, {
            text: box('🔓 *GROUPE DÉVERROUILLÉ*', '✅ Tout le monde peut modifier les infos du groupe.'),
            ...channelInfo
        }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ Erreur: ${e.message}`, ...channelInfo }, { quoted: message });
    }
}

// ADDPREM / DELPREM
const premiumUsers = new Set();
async function addpremCommand(sock, chatId, message, mentionedJids) {
    const target = mentionedJids?.[0];
    if (!target) return sock.sendMessage(chatId, { text: '❌ Mentionne un utilisateur.', ...channelInfo }, { quoted: message });
    premiumUsers.add(target);
    await sock.sendMessage(chatId, {
        text: box('⭐ *PREMIUM AJOUTÉ*', `@${target.split('@')[0]} est maintenant premium !`),
        mentions: [target], ...channelInfo
    }, { quoted: message });
}

async function delpremCommand(sock, chatId, message, mentionedJids) {
    const target = mentionedJids?.[0];
    if (!target) return sock.sendMessage(chatId, { text: '❌ Mentionne un utilisateur.', ...channelInfo }, { quoted: message });
    premiumUsers.delete(target);
    await sock.sendMessage(chatId, {
        text: box('⭐ *PREMIUM RETIRÉ*', `@${target.split('@')[0]} n'est plus premium.`),
        mentions: [target], ...channelInfo
    }, { quoted: message });
}

// AUTOVIEWSTATUS
let autoViewStatus = false;
async function autoviewstatusCommand(sock, chatId, message, arg) {
    if (!['on','off'].includes(arg)) return sock.sendMessage(chatId, { text: '❌ Usage : *.autoviewstatus on/off*', ...channelInfo }, { quoted: message });
    autoViewStatus = arg === 'on';
    await sock.sendMessage(chatId, {
        text: box('👁️ *AUTO VIEW STATUS*', `Statut : ${autoViewStatus ? '🟢 Activé' : '🔴 Désactivé'}`),
        ...channelInfo
    }, { quoted: message });
}

module.exports = {
    uptimeCommand, speedCommand, toimgCommand, qrCommand, getppCommand,
    setprefixCommand, selfCommand, broadcastCommand, grouplinkCommand,
    unlockCommand, addpremCommand, delpremCommand, autoviewstatusCommand
};
