const { channelInfo } = require('../lib/messageConfig');
const facts = ["La pieuvre a trois cœurs et un sang bleu.","Les abeilles peuvent reconnaître les visages humains.","La Grande Muraille de Chine n'est pas visible depuis l'espace.","Les dauphins dorment avec un œil ouvert.","Un éclair peut atteindre 30 000°C.","Les humains partagent 60% de leur ADN avec les bananes.","Le cœur d'une baleine bleue bat seulement 2 fois par minute.","Les chats ont 32 muscles dans chaque oreille."];
async function factCommand(sock, chatId, message) {
    const fact = facts[Math.floor(Math.random() * facts.length)];
    await sock.sendMessage(chatId, { text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n🧠 *FAIT INTÉRESSANT*\n━━━━━━━━━━━━━━━━━━\n${fact}\n\n> 💎 *CENTRAL-HEX*`, ...channelInfo }, { quoted: message });
}
module.exports = factCommand;
