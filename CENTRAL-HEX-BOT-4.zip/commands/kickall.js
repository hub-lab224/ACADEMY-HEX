// kickall.js — CENTRAL-HEX
const { channelInfo } = require('../lib/messageConfig');

async function kickallCommand(sock, chatId, message, senderId) {
    if (!chatId.endsWith('@g.us')) return sock.sendMessage(chatId, { text: '❌ Groupe uniquement.', ...channelInfo }, { quoted: message });
    try {
        const meta = await sock.groupMetadata(chatId);
        const botJid = sock.user?.id?.replace(/:\d+/, '') + '@s.whatsapp.net';
        const ownerJid = senderId;
        const toKick = meta.participants.filter(p => p.id !== botJid && p.id !== ownerJid && !p.admin);

        await sock.sendMessage(chatId, {
            text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n🦵 *KICKALL*\n━━━━━━━━━━━━━━━━━━\n⏳ Expulsion de *${toKick.length}* membres...\n(Admins et owner préservés)\n\n> 💎 *CENTRAL-HEX*`,
            ...channelInfo
        }, { quoted: message });

        for (const p of toKick) {
            try {
                await sock.groupParticipantsUpdate(chatId, [p.id], 'remove');
                await new Promise(r => setTimeout(r, 500));
            } catch {}
        }

        await sock.sendMessage(chatId, {
            text: `✅ *${toKick.length}* membres expulsés !\n\n> 💎 *CENTRAL-HEX*`,
            ...channelInfo
        });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ ${e.message}`, ...channelInfo }, { quoted: message });
    }
}
module.exports = kickallCommand;
