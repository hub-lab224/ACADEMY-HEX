const { channelInfo } = require('../lib/messageConfig');
const truths = ["Quel est ton plus grand secret que personne ne connaît ?","Qui est la personne que tu admires le plus dans ce groupe ?","Quelle est ta plus grande peur dans la vie ?","As-tu déjà menti à quelqu'un dans ce groupe ?","Quel est ton plus grand regret ?","Quelle est la chose la plus folle que tu aies jamais faite ?","Quel est ton talent caché ?","As-tu déjà eu un béguin pour quelqu'un dans ce groupe ?"];
async function truthCommand(sock, chatId, message) {
    const truth = truths[Math.floor(Math.random() * truths.length)];
    await sock.sendMessage(chatId, { text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n🤔 *VÉRITÉ (TRUTH)*\n━━━━━━━━━━━━━━━━━━\n${truth}\n\n> 💎 *CENTRAL-HEX*`, ...channelInfo }, { quoted: message });
}
module.exports = truthCommand;
