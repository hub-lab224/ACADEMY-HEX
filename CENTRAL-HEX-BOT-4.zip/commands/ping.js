const os = require('os');
const settings = require('../settings.js');
const { channelInfo } = require('../lib/messageConfig');

function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}h ${m}m ${s}s`;
}

async function pingCommand(sock, chatId, message) {
    try {
        const start = Date.now();
        await sock.sendMessage(chatId, { text: '⏳ Calcul en cours...' }, { quoted: message });
        const ping = Date.now() - start;
        const ram = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
        const uptime = formatTime(Math.floor(process.uptime()));

        const botInfo =
`╭⊰🥷⊱═══════════⊰🥷⊱
║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`
╰⊰🥷⊱═══════════⊰🥷⊱
╭═══════════════⊰۞⊱
╠╌ 📡 𝙿𝙸𝙽𝙶    : ${ping} ms
╠╌ ⏱️ 𝚄𝙿𝚃𝙸𝙼𝙴  : ${uptime}
╠╌ 💾 𝚁𝙰𝙼     : ${ram} MB
╠╌ 📦 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : v${settings.version}
╠╌ ✅ 𝚂𝚃𝙰𝚃𝚄𝚂  : En ligne
╰⊰۞⊱════════════⊰۞⊱

> 💎 by *Ibrahima Sory Sacko*`;

        await sock.sendMessage(chatId, { text: botInfo, ...channelInfo }, { quoted: message });
    } catch (e) {
        console.error('Ping error:', e);
    }
}

module.exports = pingCommand;
