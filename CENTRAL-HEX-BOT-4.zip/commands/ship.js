const { channelInfo } = require('../lib/messageConfig');
async function shipCommand(sock, chatId, message, mentionedJids) {
    if (!mentionedJids?.length || mentionedJids.length < 2) return sock.sendMessage(chatId, { text: '❌ Mentionne 2 personnes !\nEx : *.ship @user1 @user2*', ...channelInfo }, { quoted: message });
    const [u1, u2] = mentionedJids;
    const pct = Math.floor(Math.random() * 101);
    const bars = Math.round(pct / 10);
    const bar = '❤️'.repeat(bars) + '🖤'.repeat(10 - bars);
    const emoji = pct >= 80 ? '💍' : pct >= 60 ? '💕' : pct >= 40 ? '💓' : pct >= 20 ? '💔' : '😬';
    await sock.sendMessage(chatId, { text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n💘 *COMPATIBILITÉ*\n━━━━━━━━━━━━━━━━━━\n👤 @${u1.split('@')[0]}\n💕 avec\n👤 @${u2.split('@')[0]}\n\n${bar}\n\n${emoji} Compatibilité : *${pct}%*\n\n> 💎 *CENTRAL-HEX*`, mentions: [u1, u2], ...channelInfo }, { quoted: message });
}
module.exports = shipCommand;
