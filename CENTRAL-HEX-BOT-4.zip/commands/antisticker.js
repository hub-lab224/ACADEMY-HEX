// antisticker.js — CENTRAL-HEX
const fs = require('fs');
const path = require('path');
const { channelInfo } = require('../lib/messageConfig');

const dataFile = path.join(__dirname, '../data/antisticker.json');
function getData() { try { return JSON.parse(fs.readFileSync(dataFile)); } catch { return {}; } }
function saveData(d) { try { fs.writeFileSync(dataFile, JSON.stringify(d, null, 2)); } catch {} }

async function antistickerCommand(sock, chatId, message, arg) {
    if (!chatId.endsWith('@g.us')) return sock.sendMessage(chatId, { text: '❌ Groupe uniquement.', ...channelInfo }, { quoted: message });
    if (!['on','off'].includes(arg)) return sock.sendMessage(chatId, { text: '❌ Usage: *.antisticker on* | *.antisticker off*', ...channelInfo }, { quoted: message });
    const data = getData();
    data[chatId] = arg === 'on';
    saveData(data);
    await sock.sendMessage(chatId, {
        text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n🎭 *ANTISTICKER*\n━━━━━━━━━━━━━━━━━━\nStatut : ${arg === 'on' ? '🟢 Activé — Stickers supprimés' : '🔴 Désactivé'}\n\n> 💎 *CENTRAL-HEX*`,
        ...channelInfo
    }, { quoted: message });
}
function isEnabled(chatId) { return getData()[chatId] === true; }
module.exports = { antistickerCommand, isEnabled };
