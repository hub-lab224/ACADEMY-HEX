const { setAntispam } = require('../lib/index');

async function antispamCommand(sock, chatId, message, senderId, isSenderAdmin) {
    if (!isSenderAdmin) {
        return sock.sendMessage(chatId, { text: '*Désolé, seuls les administrateurs peuvent utiliser cette commande.*' }, { quoted: message });
    }

    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = text.split(' ');
    const match = args[1];

    if (!match) {
        return sock.sendMessage(chatId, {
            text: `*CONFIGURATION ANTISPAM*\n\n*.antispam on*\nActiver l'antispam\n\n*.antispam set <action>*\nDéfinir l'action: delete/kick\n\n*.antispam off*\nDésactiver l'antispam`
        }, { quoted: message });
    }

    if (match === 'on') {
        await setAntispam(chatId, 'on', 'delete');
        return sock.sendMessage(chatId, { text: '*L\'Antispam a été activé (Action par défaut: delete).*' }, { quoted: message });
    }

    if (match === 'off') {
        await setAntispam(chatId, 'off');
        return sock.sendMessage(chatId, { text: '*L\'Antispam a été désactivé.*' }, { quoted: message });
    }

    if (match === 'set') {
        const action = args[2];
        if (!action || !['delete', 'kick'].includes(action)) {
            return sock.sendMessage(chatId, { text: '*Action invalide. Choisissez: delete ou kick.*' }, { quoted: message });
        }
        await setAntispam(chatId, 'on', action);
        return sock.sendMessage(chatId, { text: `*L'action Antispam a été définie sur: ${action}*` }, { quoted: message });
    }

    return sock.sendMessage(chatId, { text: '*Commande invalide. Utilisez .antispam pour voir l\'aide.*' }, { quoted: message });
}

module.exports = antispamCommand;
