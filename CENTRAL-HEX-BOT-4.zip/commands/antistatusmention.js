// antistatusmention.js — CENTRAL-HEX
const fs = require('fs');
const path = require('path');
const { proto } = require('@whiskeysockets/baileys');
const { channelInfo } = require('../lib/messageConfig');

const dataFile = path.join(__dirname, '../data/antistatusmention.json');
function getData() { try { return JSON.parse(fs.readFileSync(dataFile)); } catch { return {}; } }
function saveData(d) { try { fs.writeFileSync(dataFile, JSON.stringify(d, null, 2)); } catch {} }

async function antimentionstatusCommand(sock, chatId, message, arg) {
    if (!chatId.endsWith('@g.us')) return sock.sendMessage(chatId, { text: '❌ Groupe uniquement.', ...channelInfo }, { quoted: message });
    if (!['on','off'].includes(arg)) return sock.sendMessage(chatId, { text: '❌ Usage: *.antistatusmention on* | *.antistatusmention off*', ...channelInfo }, { quoted: message });
    const data = getData();
    data[chatId] = arg === 'on';
    saveData(data);
    await sock.sendMessage(chatId, {
        text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n📢 *ANTISTATUSMENTION*\n━━━━━━━━━━━━━━━━━━\nStatut : ${arg === 'on' ? '🟢 Activé' : '🔴 Désactivé'}\n${arg === 'on' ? '✅ Les mentions de statut seront supprimées.' : ''}\n\n> 💎 *CENTRAL-HEX*`,
        ...channelInfo
    }, { quoted: message });
}

function isStatusMention(mek) {
    try {
        const msg = mek?.message;
        if (!msg) return false;
        if (msg.groupMentionedMessage) return true;
        for (const t of ['extendedTextMessage','imageMessage','videoMessage','stickerMessage','audioMessage']) {
            const ctx = msg[t]?.contextInfo;
            if (ctx?.remoteJid === 'status@broadcast') return true;
            if (ctx?.groupMentions?.length > 0) return true;
        }
        return false;
    } catch { return false; }
}

async function handleAntimentionStatus(sock, chatId, sender, mek) {
    try {
        if (!chatId?.endsWith('@g.us')) return false;
        if (mek?.key?.fromMe) return false;
        const data = getData();
        if (!data[chatId]) return false;
        if (!isStatusMention(mek)) return false;
        const meta = await sock.groupMetadata(chatId);
        const botJid = sock.user.id?.replace(/:\d+/, '') + '@s.whatsapp.net';
        const isBotAdmin = meta.participants.some(p => p.id === botJid && p.admin);
        if (!isBotAdmin) return false;
        const deleteKey = { remoteJid: chatId, id: mek.key.id, participant: mek.key.participant || sender, fromMe: false };
        try { await sock.sendMessage(chatId, { delete: deleteKey }); return true; } catch {}
        try {
            const revokeMsg = proto.Message.fromObject({ protocolMessage: { key: deleteKey, type: proto.Message.ProtocolMessage.Type.REVOKE } });
            await sock.relayMessage(chatId, revokeMsg, {});
            return true;
        } catch { return false; }
    } catch { return false; }
}

module.exports = { antimentionstatusCommand, handleAntimentionStatus, isStatusMention };
