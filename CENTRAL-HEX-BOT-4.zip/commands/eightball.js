const eightBallResponses = [
    "Oui, absolument ! ",
    "Pas question ! ",
    "Reposez la question plus tard. ",
    "C'est certain. ",
    "J'en doute fort. ",
    " Sans aucun doute. ",
    "Ma réponse est non. ",
    " Tout porte à croire que oui. "
];

async function eightBallCommand(sock, chatId, question) {
    if (!question) {
        await sock.sendMessage(chatId, { text: "Veuillez poser une question !" });
        return;
    }

    const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];
    await sock.sendMessage(chatId, { text: `🎱 ${randomResponse}` });
}

module.exports = { eightBallCommand };
