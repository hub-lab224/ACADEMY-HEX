const { channelInfo } = require('../lib/messageConfig');

function box(title, content) {
    return `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n${title}\n━━━━━━━━━━━━━━━━━━\n${content}\n\n> 💎 *CENTRAL-HEX*`;
}

// RIDDLE
const riddles = [
    { q: "Je parle sans bouche et entends sans oreilles. Je n'ai pas de corps mais prends vie avec le vent. Qu'est-ce que je suis ?", a: "Un écho" },
    { q: "Plus je sèche, plus je suis mouillée. Qu'est-ce que je suis ?", a: "Une serviette" },
    { q: "J'ai des villes, mais pas de maisons. J'ai des montagnes, mais pas d'arbres. J'ai de l'eau, mais pas de poissons. Qu'est-ce que je suis ?", a: "Une carte" },
    { q: "Je suis toujours devant toi mais ne peut jamais être vu. Qu'est-ce que je suis ?", a: "L'avenir" },
    { q: "Qu'est-ce qui a des dents mais ne mord pas ?", a: "Un peigne" },
    { q: "Plus je grandis, moins tu me vois. Qu'est-ce que je suis ?", a: "L'obscurité" },
];
async function riddleCommand(sock, chatId, message) {
    const r = riddles[Math.floor(Math.random() * riddles.length)];
    await sock.sendMessage(chatId, {
        text: box('🧩 *DEVINETTE*', `❓ ${r.q}\n\n_Réponds pour voir la réponse !_\n||${r.a}||`),
        ...channelInfo
    }, { quoted: message });
}

// ROAST
const roasts = [
    "Tu es la preuve que même les erreurs peuvent marcher sur deux pieds. 😂",
    "Si l'intelligence était de l'eau, tu serais le Sahara.",
    "Tu ressembles à un calendrier... utilisé une fois par an.",
    "Je me demande comment tu fais pour tenir debout avec si peu de cervelle.",
    "Tu es comme une wi-fi publique : tout le monde peut te pénétrer mais personne ne te fait vraiment confiance.",
    "Tu as le QI d'une plante, mais au moins les plantes sont utiles.",
    "Si la bêtise faisait du bruit, tu serais une sirène d'alarme.",
    "Tu es la raison pour laquelle les notices d'utilisation existent.",
];
async function roastCommand(sock, chatId, message, mentionedJids) {
    const roast = roasts[Math.floor(Math.random() * roasts.length)];
    const target = mentionedJids?.[0];
    const prefix = target ? `@${target.split('@')[0]} ` : '';
    await sock.sendMessage(chatId, {
        text: box('🔥 *ROAST*', `${prefix}${roast}`),
        mentions: target ? [target] : [],
        ...channelInfo
    }, { quoted: message });
}

// COINFLIP
async function coinflipCommand(sock, chatId, message) {
    const result = Math.random() < 0.5 ? '🪙 PILE' : '🔷 FACE';
    await sock.sendMessage(chatId, {
        text: box('🪙 *PILE OU FACE*', `Résultat : *${result}* !`),
        ...channelInfo
    }, { quoted: message });
}

// DICE
async function diceCommand(sock, chatId, message, args) {
    const faces = parseInt(args[0]) || 6;
    const result = Math.floor(Math.random() * faces) + 1;
    const dice = ['⚀','⚁','⚂','⚃','⚄','⚅'];
    const icon = faces === 6 ? dice[result - 1] : '🎲';
    await sock.sendMessage(chatId, {
        text: box('🎲 *DÉ*', `${icon} Résultat : *${result}* / ${faces}`),
        ...channelInfo
    }, { quoted: message });
}

// MAGIC8
const answers = [
    "✅ Oui, absolument !", "✅ C'est certain.", "✅ Sans aucun doute !",
    "✅ Tu peux compter dessus.", "✅ Les signes indiquent que oui.",
    "⚠️ Réessaie plus tard.", "⚠️ Difficile à dire.", "⚠️ Je ne peux pas te le dire maintenant.",
    "❌ Non, certainement pas.", "❌ Mes sources disent non.", "❌ Les perspectives ne sont pas bonnes.",
];
async function magic8Command(sock, chatId, message, question) {
    const answer = answers[Math.floor(Math.random() * answers.length)];
    const q = question || 'Ta question...';
    await sock.sendMessage(chatId, {
        text: box('🎱 *BOULE MAGIQUE*', `❓ *Question :* ${q}\n\n🎱 *Réponse :* ${answer}`),
        ...channelInfo
    }, { quoted: message });
}

module.exports = { riddleCommand, roastCommand, coinflipCommand, diceCommand, magic8Command };
