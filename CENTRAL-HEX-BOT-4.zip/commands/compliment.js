const { channelInfo } = require('../lib/messageConfig');
const compliments = ["Tu illumines chaque conversation comme le soleil ☀️","Ta présence rend ce groupe meilleur ! 💎","Tu es une personne exceptionnelle avec un cœur en or ! ❤️","Ton intelligence est une inspiration pour tous ! 🌟","Tu as le don de rendre les gens heureux ! 😊","Tu es plus fort(e) que tu ne le penses ! 💪","Le monde est meilleur avec toi dedans ! 🌍","Ta créativité est sans limites ! 🎨"];
async function complimentCommand(sock, chatId, message, mentionedJids) {
    const c = compliments[Math.floor(Math.random() * compliments.length)];
    const target = mentionedJids?.[0];
    const prefix = target ? `@${target.split('@')[0]} ` : '';
    await sock.sendMessage(chatId, { text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n💝 *COMPLIMENT*\n━━━━━━━━━━━━━━━━━━\n${prefix}${c}\n\n> 💎 *CENTRAL-HEX*`, mentions: target ? [target] : [], ...channelInfo }, { quoted: message });
}
module.exports = complimentCommand;
