// stickersearch.js — CENTRAL-HEX
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { channelInfo } = require('../lib/messageConfig');

const tmpDir = path.join(__dirname, '../tmp');
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

const cooldowns = new Map();

async function imageToWebp(imageUrl) {
    const uid = Date.now() + Math.random().toString(36).slice(2);
    const tempIn = path.join(tmpDir, `ss_in_${uid}.jpg`);
    const tempOut = path.join(tmpDir, `ss_out_${uid}.webp`);
    try {
        const r = await axios.get(imageUrl, { responseType: 'arraybuffer', timeout: 15000 });
        fs.writeFileSync(tempIn, Buffer.from(r.data));
        await new Promise((res, rej) => exec(`ffmpeg -i "${tempIn}" -vf "scale=512:512:flags=lanczos" -c:v libwebp -q:v 80 -y "${tempOut}"`, { timeout: 20000 }, err => err ? rej(err) : res()));
        if (!fs.existsSync(tempOut)) throw new Error('Convert failed');
        return fs.readFileSync(tempOut);
    } finally {
        try { if (fs.existsSync(tempIn)) fs.unlinkSync(tempIn); } catch {}
        try { if (fs.existsSync(tempOut)) fs.unlinkSync(tempOut); } catch {}
    }
}

async function gifToSticker(gifUrl) {
    const uid = Date.now() + Math.random().toString(36).slice(2);
    const tempIn = path.join(tmpDir, `gif_${uid}.gif`);
    const tempOut = path.join(tmpDir, `anim_${uid}.webp`);
    try {
        const r = await axios.get(gifUrl, { responseType: 'arraybuffer', timeout: 20000 });
        fs.writeFileSync(tempIn, Buffer.from(r.data));
        await new Promise((res, rej) => exec(`ffmpeg -i "${tempIn}" -vf "scale=512:512:flags=lanczos,fps=15" -c:v libwebp -q:v 75 -loop 0 -an -vsync 0 -y "${tempOut}"`, { timeout: 30000 }, err => err ? rej(err) : res()));
        if (!fs.existsSync(tempOut)) throw new Error('Animated convert failed');
        return fs.readFileSync(tempOut);
    } finally {
        try { if (fs.existsSync(tempIn)) fs.unlinkSync(tempIn); } catch {}
        try { if (fs.existsSync(tempOut)) fs.unlinkSync(tempOut); } catch {}
    }
}

async function stickersearchCommand(sock, chatId, senderId, message, query) {
    if (!query) return sock.sendMessage(chatId, {
        text: '❌ Usage: *.stickersearch <texte>*\nEx: .stickersearch Naruto',
        ...channelInfo
    }, { quoted: message });

    const lastUse = cooldowns.get(senderId);
    if (lastUse && Date.now() - lastUse < 15000) {
        const reste = Math.ceil((15000 - (Date.now() - lastUse)) / 1000);
        return sock.sendMessage(chatId, { text: `⏳ Attends *${reste}s*`, ...channelInfo }, { quoted: message });
    }
    cooldowns.set(senderId, Date.now());

    await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });
    await sock.sendMessage(chatId, { text: `🔍 Recherche de stickers *"${query}"*...\n📸 5 statiques + 🎬 5 animés`, ...channelInfo }, { quoted: message });

    try {
        // Images statiques
        let imageUrls = [];
        try {
            const r = await axios.get(`https://christus-api.vercel.app/image/Pinterest?query=${encodeURIComponent(query + ' sticker')}&limit=8`, { timeout: 12000 });
            imageUrls = (r.data?.results || []).map(i => i?.imageUrl || i?.url || i).filter(u => typeof u === 'string' && /\.(jpg|jpeg|png|webp)/i.test(u)).slice(0, 5);
        } catch {}

        // GIFs animés
        let gifUrls = [];
        try {
            const r = await axios.get(`https://api.giphy.com/v1/gifs/search?api_key=qnl7ssQChTdPjsKta2Ax2LMaGXz303tq&q=${encodeURIComponent(query)}&limit=8&rating=g`, { timeout: 12000 });
            gifUrls = (r.data?.data || []).map(g => g?.images?.fixed_height?.url).filter(Boolean).slice(0, 5);
        } catch {}

        let sentImg = 0, sentGif = 0;

        // Envoyer stickers statiques
        if (imageUrls.length) {
            await sock.sendMessage(chatId, { text: `📸 Stickers image (${Math.min(5, imageUrls.length)})...`, ...channelInfo });
            for (const url of imageUrls.slice(0, 5)) {
                try { const buf = await imageToWebp(url); await sock.sendMessage(chatId, { sticker: buf, ...channelInfo }); sentImg++; await new Promise(r => setTimeout(r, 700)); } catch {}
            }
        }

        // Envoyer stickers animés
        if (gifUrls.length) {
            await sock.sendMessage(chatId, { text: `🎬 Stickers animés (${Math.min(5, gifUrls.length)})...`, ...channelInfo });
            for (const url of gifUrls.slice(0, 5)) {
                try { const buf = await gifToSticker(url); await sock.sendMessage(chatId, { sticker: buf, ...channelInfo }); sentGif++; await new Promise(r => setTimeout(r, 1000)); } catch {}
            }
        }

        const total = sentImg + sentGif;
        if (total === 0) throw new Error('Aucun sticker converti');
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });
        await sock.sendMessage(chatId, { text: `✅ *${total}/10 stickers envoyés !*\n📸 Images: ${sentImg}/5 | 🎬 Animés: ${sentGif}/5\n\n> 💎 *CENTRAL-HEX*`, ...channelInfo });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ ${e.message}`, ...channelInfo }, { quoted: message });
    }
}
module.exports = stickersearchCommand;
