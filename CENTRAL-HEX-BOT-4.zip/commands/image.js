// image.js — CENTRAL-HEX — Pinterest Search
const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

async function imageCommand(sock, chatId, message, query) {
    if (!query) return sock.sendMessage(chatId, {
        text: '❌ Usage: *.image <texte>*\nEx: .image Naruto',
        ...channelInfo
    }, { quoted: message });
    try {
        await sock.sendMessage(chatId, { react: { text: '🔍', key: message.key } });
        await sock.sendMessage(chatId, { text: `🔍 Recherche *"${query}"*...`, ...channelInfo }, { quoted: message });
        let images = [];
        const apis = [
            `https://christus-api.vercel.app/image/Pinterest?query=${encodeURIComponent(query)}&limit=10`,
            `https://api.giftedtech.my.id/api/search/pinterest?apikey=gifted&query=${encodeURIComponent(query)}`
        ];
        for (const url of apis) {
            try {
                const r = await axios.get(url, { timeout: 15000 });
                const res = r.data?.results || r.data?.result || [];
                images = res.filter(i => { const u = i?.imageUrl||i?.url||i; return typeof u === 'string' && /\.(jpg|jpeg|png|webp)/i.test(u); }).slice(0, 5);
                if (images.length) break;
            } catch {}
        }
        if (!images.length) throw new Error('Aucune image trouvée.');
        for (const img of images) {
            const url = img?.imageUrl||img?.url||img;
            try {
                await sock.sendMessage(chatId, { image: { url }, caption: `📷 *${query}*\n> 💎 *CENTRAL-HEX*`, ...channelInfo });
                await new Promise(r => setTimeout(r, 800));
            } catch {}
        }
        await sock.sendMessage(chatId, { react: { text: '✅', key: message.key } });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ ${e.message}`, ...channelInfo }, { quoted: message });
    }
}
module.exports = imageCommand;
