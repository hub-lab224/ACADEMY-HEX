// footballnews.js — CENTRAL-HEX
const axios = require('axios');
const { channelInfo } = require('../lib/messageConfig');

async function footballnewsCommand(sock, chatId, message) {
    await sock.sendMessage(chatId, { text: '⚽ Chargement des infos football...', ...channelInfo }, { quoted: message });
    const today = new Date();
    const dateISO = today.toISOString().split('T')[0];
    const dateFR = today.toLocaleDateString('fr-FR', { weekday:'long', year:'numeric', month:'long', day:'numeric' });

    let matchsAVenir = [], matchsTermines = [], matchsEnCours = [], sourceUsed = '';
    try {
        const r = await axios.get(`https://www.thesportsdb.com/api/v1/json/3/eventsday.php?d=${dateISO}&s=Soccer`, { timeout: 10000 });
        const events = r.data?.events || [];
        events.slice(0, 12).forEach(e => {
            const home = e.strHomeTeam || 'Équipe A';
            const away = e.strAwayTeam || 'Équipe B';
            const league = e.strLeague || 'Liga';
            const time = e.strTime ? e.strTime.slice(0, 5) : '--:--';
            if (e.intHomeScore !== null && e.intHomeScore !== '') {
                matchsTermines.push(`✅ *${home}* ${e.intHomeScore} - ${e.intAwayScore} *${away}*\n   📍 ${league}`);
            } else {
                matchsAVenir.push(`⚽ *${home}* VS *${away}*\n   ⏰ ${time} | 📍 ${league}`);
            }
        });
        if (events.length > 0) sourceUsed = 'TheSportsDB';
    } catch {}

    let caption = `╭⊰🥷⊱═══════════⊰🥷⊱\n║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n⚽ *FOOTBALL NEWS*\n📅 ${dateFR}\n`;
    if (sourceUsed) caption += `📡 Source: ${sourceUsed}\n`;
    caption += `\n╭═══════════════⊰۞⊱\n🏟️ *MATCHS DU JOUR*\n╰⊰۞⊱════════════⊰۞⊱\n\n`;
    caption += matchsEnCours.length ? matchsEnCours.join('\n\n') + '\n\n' : '';
    caption += matchsAVenir.length ? matchsAVenir.slice(0,6).join('\n\n') + '\n\n' : '❌ Aucun match programmé\n\n';
    caption += `╭═══════════════⊰۞⊱\n📊 *RÉSULTATS*\n╰⊰۞⊱════════════⊰۞⊱\n\n`;
    caption += matchsTermines.length ? matchsTermines.slice(0,6).join('\n\n') : '❌ Aucun résultat disponible';
    caption += `\n\n> 💎 *CENTRAL-HEX*`;

    await sock.sendMessage(chatId, { text: caption, ...channelInfo }, { quoted: message });
}
module.exports = footballnewsCommand;
