// tag.js — CENTRAL-HEX
const { channelInfo } = require('../lib/messageConfig');

async function tagCommand(sock, chatId, message, text) {
    if (!chatId.endsWith('@g.us')) return sock.sendMessage(chatId, { text: '❌ Groupe uniquement.', ...channelInfo }, { quoted: message });
    const mentionedJids = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentionedJids.length) return sock.sendMessage(chatId, { text: '❌ Mentionne au moins une personne.\nEx: .tag @user message', ...channelInfo }, { quoted: message });
    const msg = text || '👋 Salut !';
    await sock.sendMessage(chatId, {
        text: `╭⊰🥷⊱═══════════⊰🥷⊱\n║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`\n╰⊰🥷⊱═══════════⊰🥷⊱\n\n📌 *TAG*\n━━━━━━━━━━━━━━━━━━\n${mentionedJids.map(j => `@${j.split('@')[0]}`).join(' ')}\n\n💬 ${msg}\n\n> 💎 *CENTRAL-HEX*`,
        mentions: mentionedJids,
        ...channelInfo
    }, { quoted: message });
}
module.exports = tagCommand;
