const moment = require('moment-timezone');
const fs = require('fs');
const path = require('path');
const settings = require('../settings.js');
const { channelInfo } = require('../lib/messageConfig');

async function helpCommand(sock, chatId, message) {
    const date = moment().tz('Africa/Conakry').format('DD/MM/YYYY');
    const time = moment().tz('Africa/Conakry').format('HH:mm:ss');
    const uptime = (() => { const s = Math.floor(process.uptime()); return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m`; })();

    const helpMessage =
`╭⊰🥷⊱═══════════⊰🥷⊱
║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`
╰⊰🥷⊱═══════════⊰🥷⊱
╭═══════════════⊰۞⊱
╠╌ 👤 𝙾𝚆𝙽𝙴𝚁 : ${settings.botOwner}
╠╌ ⏰ 𝙷𝙴𝚄𝚁𝙴 : ${time}
╠╌ 📅 𝙳𝙰𝚃𝙴 : ${date}
╠╌ 📦 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : v${settings.version}
╠╌ 📋 𝙲𝙾𝙼𝙼𝙰𝙽𝙳𝙴𝚂 : 60+
╠╌ 🔑 𝙿𝚁𝙴𝙵𝙸𝚇 : [ . ]
╠╌ 🕐 𝚄𝙿𝚃𝙸𝙼𝙴 : ${uptime}
╰⊰۞⊱════════════⊰۞⊱

⊰★⊱❐ ⌜𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒⌟ ❐ ⊰★⊱

╭⊰ \`𝐆𝐄𝐍𝐄𝐑𝐀𝐋\` ⊱ 📃
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .menu → afficher le menu
╠🥷 ❐ .allmenu → toutes les commandes
╠🥷 ❐ .ping → vitesse du bot
╠🥷 ❐ .alive → état du bot
╠🥷 ❐ .owner → infos propriétaire
╠🥷 ❐ .uptime → temps en ligne
╠🥷 ❐ .speed → vitesse réseau
╠🥷 ❐ .repo → dépôt GitHub
╠🥷 ❐ .support → lien support
╠🥷 ❐ .footballnews → actu football
╠🥷 ❐ .gpt → ChatGPT IA
╠🥷 ❐ .codeai → générer code IA
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐏𝐑𝐎𝐏𝐑𝐈𝐄𝐓𝐀𝐈𝐑𝐄\` ⊱ 👑
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .setprefix → changer préfixe
╠🥷 ❐ .public → mode public
╠🥷 ❐ .self → mode privé
╠🥷 ❐ .antidelete on/off → anti-suppression
╠🥷 ❐ .anticall on/off → bloquer appels
╠🥷 ❐ .autoviewstatus on/off → voir statuts
╠🥷 ❐ .block @user → bloquer user
╠🥷 ❐ .unblock @user → débloquer user
╠🥷 ❐ .broadcast → message diffusion
╠🥷 ❐ .addprem @user → ajouter premium
╠🥷 ❐ .delprem @user → retirer premium
╠🥷 ❐ .mode public/private → changer mode
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐆𝐑𝐎𝐔𝐏𝐄\` ⊱ 👥
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .promote @user → rendre admin
╠🥷 ❐ .demote @user → retirer admin
╠🥷 ❐ .kick @user → expulser membre
╠🥷 ❐ .kickall → expulser tous
╠🥷 ❐ .mute → fermer le groupe
╠🥷 ❐ .unmute → ouvrir le groupe
╠🥷 ❐ .tagall → mentionner tous
╠🥷 ❐ .tag @user texte → taguer user
╠🥷 ❐ .hidetag texte → tag caché
╠🥷 ❐ .grouplink → lien du groupe
╠🥷 ❐ .revoke → révoquer le lien
╠🥷 ❐ .groupinfo → infos du groupe
╠🥷 ❐ .setgname → changer nom groupe
╠🥷 ❐ .warn @user → avertir membre
╠🥷 ❐ .resetwarn @user → reset warns
╠🥷 ❐ .warnings @user → voir avertissements
╠🥷 ❐ .welcome on/off → msg bienvenue
╠🥷 ❐ .goodbye on/off → msg au revoir
╠🥷 ❐ .lock → verrouiller groupe
╠🥷 ❐ .unlock → déverrouiller groupe
╠🥷 ❐ .everyone → mentionner tous
╠🥷 ❐ .admins → lister les admins
╠🥷 ❐ .members → lister les membres
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐈𝐎𝐍\` ⊱ 🛡️
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .antilink on/off → bloquer liens
╠🥷 ❐ .antispam on/off → anti-spam
╠🥷 ❐ .antibadword on/off → anti-insultes
╠🥷 ❐ .antimarabout on/off → anti-arnaques
╠🥷 ❐ .antidelete on/off → anti-suppression
╠🥷 ❐ .antibot on/off → bloquer bots
╠🥷 ❐ .antitag on/off → anti-tag abusif
╠🥷 ❐ .antimention on/off → anti-mention
╠🥷 ❐ .antistatusmention on/off → anti-statut
╠🥷 ❐ .antisticker on/off → anti-sticker
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐔𝐓𝐈𝐋𝐈𝐓𝐀𝐈𝐑𝐄\` ⊱ 🛠️
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .sticker → créer un sticker
╠🥷 ❐ .toimg → sticker en image
╠🥷 ❐ .take → modifier sticker
╠🥷 ❐ .attp → texte en sticker
╠🥷 ❐ .qr → générer code QR
╠🥷 ❐ .tts → texte en audio
╠🥷 ❐ .tr → traduire un texte
╠🥷 ❐ .shorten → raccourcir lien
╠🥷 ❐ .getpp → photo de profil
╠🥷 ❐ .vv → voir message éphémère
╠🥷 ❐ .waouh → capture discrète media
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐅𝐔𝐍\` ⊱ 🎮
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .joke → blague aléatoire
╠🥷 ❐ .fact → fait intéressant
╠🥷 ❐ .quote → citation inspirante
╠🥷 ❐ .dare → action à faire
╠🥷 ❐ .truth → vérité à dire
╠🥷 ❐ .riddle → devinette
╠🥷 ❐ .roast → humour piquant
╠🥷 ❐ .ship @u1 @u2 → compatibilité
╠🥷 ❐ .coinflip → pile ou face
╠🥷 ❐ .dice → lancer un dé
╠🥷 ❐ .magic8 → boule magique
╠🥷 ❐ .trivia → quiz culture
╠🥷 ❐ .compliment → compliment
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐃𝐄𝐕𝐄𝐋𝐎𝐏𝐏𝐄𝐔𝐑\` ⊱ 💻
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .uuid → générer UUID
╠🥷 ❐ .password → mot de passe sécurisé
╠🥷 ❐ .b64enc → encoder base64
╠🥷 ❐ .b64dec → décoder base64
╠🥷 ❐ .md5 → hash MD5
╠🥷 ❐ .sha256 → hash SHA256
╠🥷 ❐ .ipinfo → infos adresse IP
╠🥷 ❐ .whois → infos domaine
╠🥷 ❐ .shorten → raccourcir URL
╠🥷 ❐ .timestamp → horodatage actuel
╠🥷 ❐ .lorem → texte lorem ipsum
╰⊰۞⊱═════════════⊰۞⊱

╭⊰🥷⊱═══════════⊰🥷⊱
║  💎 *CENTRAL-HEX*
║  by *Ibrahima Sory Sacko*
╰⊰🥷⊱═══════════⊰🥷⊱`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        if (fs.existsSync(imagePath)) {
            await sock.sendMessage(chatId, {
                image: fs.readFileSync(imagePath),
                caption: helpMessage,
                ...channelInfo
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, { text: helpMessage, ...channelInfo }, { quoted: message });
        }
    } catch (e) {
        await sock.sendMessage(chatId, { text: helpMessage, ...channelInfo }, { quoted: message });
    }
}
module.exports = helpCommand;
