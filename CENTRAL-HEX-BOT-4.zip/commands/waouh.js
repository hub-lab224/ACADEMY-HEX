// waouh.js — CENTRAL-HEX
// Capture discrète d'image/vidéo et envoi en PV à l'owner
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const { channelInfo } = require('../lib/messageConfig');
const settings = require('../settings');

const OWNER_JID = settings.ownerNumber + '@s.whatsapp.net';

async function waouhCommand(sock, chatId, senderId, message) {
    try {
        // Récupérer le message cité
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage ||
                       message.message?.imageMessage?.contextInfo?.quotedMessage ||
                       message.message?.videoMessage?.contextInfo?.quotedMessage;

        const ctx = message.message?.extendedTextMessage?.contextInfo ||
                    message.message?.imageMessage?.contextInfo ||
                    message.message?.videoMessage?.contextInfo;

        if (!quoted || !ctx?.stanzaId) {
            return sock.sendMessage(chatId, {
                text: '❌ Réponds à une image ou vidéo avec *.waouh*',
                ...channelInfo
            }, { quoted: message });
        }

        let mediaType;
        if (quoted.imageMessage) mediaType = 'image';
        else if (quoted.videoMessage) mediaType = 'video';
        else {
            return sock.sendMessage(chatId, {
                text: '❌ Ce doit être une image ou une vidéo !',
                ...channelInfo
            }, { quoted: message });
        }

        // Télécharger le média
        const targetMsg = {
            key: {
                remoteJid: chatId,
                id: ctx.stanzaId,
                participant: ctx.participant,
                fromMe: false
            },
            message: quoted
        };

        const buffer = await downloadMediaMessage(targetMsg, 'buffer', {});
        if (!buffer) throw new Error('Téléchargement échoué');

        // Envoyer en PV à l'owner
        await sock.sendMessage(OWNER_JID, {
            [mediaType]: buffer,
            caption: `👀 *Waouh* — CENTRAL-HEX\n📱 De : @${senderId.split('@')[0]}\n💬 Chat : ${chatId}`
        });

        // Réaction discrète + supprimer la commande
        await sock.sendMessage(chatId, {
            react: { text: '👀', key: message.key }
        });

        // Supprimer le message de commande discrètement
        try {
            await sock.sendMessage(chatId, { delete: message.key });
        } catch {}

    } catch (e) {
        console.error('❌ waouh error:', e.message);
    }
}

module.exports = waouhCommand;
