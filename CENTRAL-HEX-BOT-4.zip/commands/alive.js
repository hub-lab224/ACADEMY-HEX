const { channelInfo } = require('../lib/messageConfig');
const settings = require('../settings');

async function aliveCommand(sock, chatId, message) {
    const uptime = (() => {
        const s = Math.floor(process.uptime());
        return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m ${Math.floor(s%60)}s`;
    })();
    const ram = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);

    await sock.sendMessage(chatId, {
        text:
`╭⊰🥷⊱═══════════⊰🥷⊱
║  〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙
╰⊰🥷⊱═══════════⊰🥷⊱

✅ *CENTRAL-HEX est Actif !*
━━━━━━━━━━━━━━━━━━
📦 *Version* : v${settings.version}
✅ *Statut*  : En ligne
🌐 *Mode*    : ${settings.commandMode || 'Public'}
━━━━━━━━━━━━━━━━━━
⭐ *Fonctionnalités :*
• Gestion de groupes
• Protection antilink/antispam
• Commandes IA (GPT, CodeAI)
• Fun & Jeux
• Et bien plus !

💡 Tape *.menu* pour la liste complète

> 💎 *CENTRAL-HEX* | by *Ibrahima Sory Sacko*`,
        ...channelInfo
    }, { quoted: message });
}
module.exports = aliveCommand;
