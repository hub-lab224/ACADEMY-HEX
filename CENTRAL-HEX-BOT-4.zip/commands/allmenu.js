// allmenu.js — CENTRAL-HEX
const moment = require('moment-timezone');
const settings = require('../settings');
const { channelInfo } = require('../lib/messageConfig');

async function allmenuCommand(sock, chatId, message) {
    const date = moment().tz('Africa/Conakry').format('DD/MM/YYYY');
    const time = moment().tz('Africa/Conakry').format('HH:mm:ss');
    const uptime = (() => { const s = Math.floor(process.uptime()); return `${Math.floor(s/3600)}h ${Math.floor((s%3600)/60)}m`; })();

    const text =
`╭⊰🥷⊱═══════════⊰🥷⊱
║  \`〘 𝐂𝐄𝐍𝐓𝐑𝐀𝐋-𝐇𝐄𝐗 〙\`
╰⊰🥷⊱═══════════⊰🥷⊱
╭═══════════════⊰۞⊱
╠╌ 👤 𝙾𝚆𝙽𝙴𝚁 : ${settings.botOwner}
╠╌ ⏰ 𝙷𝙴𝚄𝚁𝙴 : ${time}
╠╌ 📅 𝙳𝙰𝚃𝙴 : ${date}
╠╌ 📦 𝚅𝙴𝚁𝚂𝙸𝙾𝙽 : v${settings.version}
╠╌ 🔑 𝙿𝚁𝙴𝙵𝙸𝚇 : [ . ]
╠╌ 🕐 𝚄𝙿𝚃𝙸𝙼𝙴 : ${uptime}
╰⊰۞⊱════════════⊰۞⊱

⊰★⊱❐ ⌜𝐓𝐎𝐔𝐓𝐄𝐒 𝐋𝐄𝐒 𝐂𝐎𝐌𝐌𝐀𝐍𝐃𝐄𝐒⌟ ❐ ⊰★⊱

╭⊰ \`𝐆𝐄𝐍𝐄𝐑𝐀𝐋\` ⊱ 📃
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .menu — menu principal
╠🥷 ❐ .allmenu — toutes les cmds
╠🥷 ❐ .ping — vitesse bot
╠🥷 ❐ .alive — état du bot
╠🥷 ❐ .owner — propriétaire
╠🥷 ❐ .uptime — temps en ligne
╠🥷 ❐ .speed — vitesse
╠🥷 ❐ .repo — dépôt bot
╠🥷 ❐ .support — support
╠🥷 ❐ .footballnews — foot
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐏𝐑𝐎𝐏𝐑𝐈𝐄𝐓𝐀𝐈𝐑𝐄\` ⊱ 👑
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .setprefix — changer préfixe
╠🥷 ❐ .public — mode public
╠🥷 ❐ .self — mode privé
╠🥷 ❐ .antidelete on/off
╠🥷 ❐ .anticall on/off
╠🥷 ❐ .autoviewstatus on/off
╠🥷 ❐ .block — bloquer user
╠🥷 ❐ .unblock — débloquer user
╠🥷 ❐ .broadcast — diffusion
╠🥷 ❐ .addprem — ajouter premium
╠🥷 ❐ .delprem — retirer premium
╠🥷 ❐ .mode — mode public/privé
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐆𝐑𝐎𝐔𝐏𝐄\` ⊱ 👥
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .promote — rendre admin
╠🥷 ❐ .demote — retirer admin
╠🥷 ❐ .kick — expulser membre
╠🥷 ❐ .kickall — expulser tous
╠🥷 ❐ .mute — muter groupe
╠🥷 ❐ .unmute — démuter
╠🥷 ❐ .tagall — mentionner tous
╠🥷 ❐ .tag — mentionner user
╠🥷 ❐ .hidetag — tag caché
╠🥷 ❐ .grouplink — lien groupe
╠🥷 ❐ .revoke — révoquer lien
╠🥷 ❐ .groupinfo — infos groupe
╠🥷 ❐ .setgname — changer nom
╠🥷 ❐ .warn — avertissement
╠🥷 ❐ .resetwarn — reset warn
╠🥷 ❐ .warnings — voir warns
╠🥷 ❐ .welcome — msg bienvenue
╠🥷 ❐ .goodbye — msg au revoir
╠🥷 ❐ .lock — verrouiller
╠🥷 ❐ .unlock — déverrouiller
╠🥷 ❐ .listgroups — liste groupes
╠🥷 ❐ .everyone — mentionner tous
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐏𝐑𝐎𝐓𝐄𝐂𝐓𝐈𝐎𝐍\` ⊱ 🛡️
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .antilink on/off
╠🥷 ❐ .antispam on/off
╠🥷 ❐ .antibadword on/off
╠🥷 ❐ .antimarabout on/off
╠🥷 ❐ .antisticker on/off
╠🥷 ❐ .antibot on/off
╠🥷 ❐ .antitag on/off
╠🥷 ❐ .antimention on/off
╠🥷 ❐ .antistatusmention on/off
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐔𝐓𝐈𝐋𝐈𝐓𝐀𝐈𝐑𝐄\` ⊱ 🛠️
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .sticker — créer sticker
╠🥷 ❐ .stickersearch — chercher
╠🥷 ❐ .toimg — sticker→image
╠🥷 ❐ .take — modifier sticker
╠🥷 ❐ .image — chercher images
╠🥷 ❐ .qr — code QR
╠🥷 ❐ .tts — texte en audio
╠🥷 ❐ .shorten — raccourcir lien
╠🥷 ❐ .getpp — photo profil
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐈𝐀\` ⊱ 🤖
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .gpt — ChatGPT IA
╠🥷 ❐ .codeai — générer code
╠🥷 ❐ .chatbot — chat avec IA
╠🥷 ❐ .ai — intelligence IA
╠🥷 ❐ .imagine — image IA
╠🥷 ❐ .translate — traduire
╰⊰۞⊱═════════════⊰۞⊱

╭⊰ \`𝐅𝐔𝐍\` ⊱ 🎮
╠⊰✦⊱═════════════⊰✦⊱
╠🥷 ❐ .joke — blague
╠🥷 ❐ .fact — fait intéressant
╠🥷 ❐ .quote — citation
╠🥷 ❐ .dare — action
╠🥷 ❐ .truth — vérité
╠🥷 ❐ .riddle — devinette
╠🥷 ❐ .roast — humour
╠🥷 ❐ .ship — compatibilité
╠🥷 ❐ .coinflip — pile/face
╠🥷 ❐ .dice — dé
╠🥷 ❐ .magic8 — boule magique
╠🥷 ❐ .meme — mème
╠🥷 ❐ .trivia — quiz
╠🥷 ❐ .compliment — compliment
╠🥷 ❐ .footballnews — foot 🔥
╰⊰۞⊱═════════════⊰۞⊱

╭⊰🥷⊱═══════════⊰🥷⊱
║  💎 *CENTRAL-HEX*
║  by *Ibrahima Sory Sacko*
╰⊰🥷⊱═══════════⊰🥷⊱`;

    await sock.sendMessage(chatId, { text, ...channelInfo }, { quoted: message });
}
module.exports = allmenuCommand;
